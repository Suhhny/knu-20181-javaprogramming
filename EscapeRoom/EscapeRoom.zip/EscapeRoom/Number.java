class Number{
   static int TakeNum(){
      return (int)(Math.random()*9+1);
   }
}
